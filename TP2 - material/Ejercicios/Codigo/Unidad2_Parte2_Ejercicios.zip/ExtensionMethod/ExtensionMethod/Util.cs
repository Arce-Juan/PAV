using System;

namespace Extensions
{
	static class Util
	{
		// TODO:
	}
}