
namespace Parameters
{
	class WrappedInt
	{
		// TODO:
	}
}

