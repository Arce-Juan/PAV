using System;

namespace StructsAndEnums
{
	// TODO:
}
