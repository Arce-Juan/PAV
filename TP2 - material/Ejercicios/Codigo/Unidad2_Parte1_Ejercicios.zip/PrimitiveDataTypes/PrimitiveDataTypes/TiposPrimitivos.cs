﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimitiveDataTypes
{
    public partial class TiposPrimitivos : Form
    {
        public TiposPrimitivos()
        {
            InitializeComponent();
        }

        private void lbTipos_SelectedValueChanged(object sender, EventArgs e)
        {
            switch (lbTipos.SelectedItem.ToString())
            {
                case "int":
                    showIntValue();
                    break;
                case "long":
                    showLongValue();
                    break;
                case "float":
                    showFloatValue();
                    break;
                case "double":
                    showDoubleValue();
                    break;
                case "decimal":
                    showDecimalValue();
                    break;
                case "string":
                    showStringValue();
                    break;
                case "char":
                    showCharValue();
                    break;
                case "bool":
                    showBoolValue();
                    break;
            }
        }

        private void showIntValue()
        {
            txtEjemplo.Text = "to do";
        }

        private void showLongValue()
        {
            long longVar;
            longVar = 42L;
            txtEjemplo.Text = longVar.ToString();
        }

        private void showFloatValue()
        {
            float floatVar;
            floatVar = 0.42F;
            txtEjemplo.Text = floatVar.ToString();
        }

        private void showDoubleValue()
        {
            txtEjemplo.Text = "to do";
        }

        private void showDecimalValue()
        {
            decimal decimalVar;
            decimalVar = 0.42M;
            txtEjemplo.Text = decimalVar.ToString();
        }

        private void showStringValue()
        {
            string stringVar;
            stringVar = "forty two";
            txtEjemplo.Text = stringVar; // ToString not needed
        }

        private void showCharValue()
        {
            char charVar;
            charVar = 'x';
            txtEjemplo.Text = charVar.ToString();
        }

        private void showBoolValue()
        {
            txtEjemplo.Text = "to do";
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
