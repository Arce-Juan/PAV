using System;

namespace Parameters
{
	class Pass
	{
		// TODO:
	}
}