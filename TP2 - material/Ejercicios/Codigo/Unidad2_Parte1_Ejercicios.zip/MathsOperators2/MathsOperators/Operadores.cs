﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathsOperators
{
    public partial class Operadores : Form
    {
        public Operadores()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((bool)rbSuma.Checked)
            {
                addValues();
            }
            else if ((bool)rbResta.Checked)
            {
                subtractValues();
            }
            else if ((bool)rbMultiplicacion.Checked)
            {
                multiplyValues();
            }
            else if ((bool)rbDivision.Checked)
            {
                divideValues();
            }
            else if ((bool)rbResto.Checked)
            {
                remainderValues();
            }
        }

        private void addValues()
        {
            int lhs = int.Parse(txtOperIzq.Text);
            int rhs = int.Parse(txtOperDcha.Text);
            int outcome = 0;

            outcome = lhs + rhs;
            lblExpresion.Text = txtOperIzq.Text + " + " + txtOperDcha.Text;
            lblResultado.Text = outcome.ToString();
        }

        private void subtractValues()
        {
            int valor = 0;
            int lhs = int.Parse(txtOperIzq.Text);
            int rhs = int.Parse(txtOperDcha.Text);
            int outcome = 0;

            outcome = lhs - rhs;
            lblExpresion.Text = txtOperIzq.Text + " - " + txtOperDcha.Text;
            lblResultado.Text = outcome.ToString();
        }

        private void multiplyValues()
        {
            int lhs = int.Parse(txtOperIzq.Text);
            int rhs = int.Parse(txtOperDcha.Text);
            int outcome = 0;

            outcome = lhs * rhs;
            lblExpresion.Text = txtOperIzq.Text + " * " + txtOperDcha.Text;
            lblResultado.Text = outcome.ToString();
        }

        private void divideValues()
        {
            int lhs = int.Parse(txtOperIzq.Text);
            int rhs = int.Parse(txtOperDcha.Text);
            int outcome = 0;

            outcome = lhs / rhs;
            lblExpresion.Text = txtOperIzq.Text + " / " + txtOperDcha.Text;
            lblResultado.Text = outcome.ToString();
        }

        private void remainderValues()
        {
            int lhs = int.Parse(txtOperIzq.Text);
            int rhs = int.Parse(txtOperDcha.Text);
            int outcome = 0;

            outcome = lhs % rhs;
            lblExpresion.Text = txtOperIzq.Text + " % " + txtOperDcha.Text;
            lblResultado.Text = outcome.ToString();
        }
    }
}
