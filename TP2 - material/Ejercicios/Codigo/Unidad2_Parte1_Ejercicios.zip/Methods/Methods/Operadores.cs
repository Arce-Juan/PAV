﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathsOperators
{
    public partial class Operadores : Form
    {
        public Operadores()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int calculatedValue = 0;

            try
            {
                int leftHandSide = System.Int32.Parse(txtOperIzq.Text);
                int rightHandSide = System.Int32.Parse(txtOperDcha.Text);

                if (rbSuma.Checked)
                {
                    calculatedValue = addValues(leftHandSide, rightHandSide);
                    showResult(calculatedValue);
                }
                else if (rbResta.Checked)
                {
                    calculatedValue = subtractValues(leftHandSide, rightHandSide);
                    showResult(calculatedValue);
                }
                else if (rbMultiplicacion.Checked)
                {
                    calculatedValue = multiplyValues(leftHandSide, rightHandSide);
                    showResult(calculatedValue);
                }
                else if (rbDivision.Checked)
                {
                    calculatedValue = divideValues(leftHandSide, rightHandSide);
                    showResult(calculatedValue);
                }
                else if (rbResto.Checked)
                {
                    calculatedValue = remainderValues(leftHandSide, rightHandSide);
                    showResult(calculatedValue);
                }
            }
            catch (Exception caught)
            {
                lblExpresion.Text = "";
                lblResultado.Text = caught.Message;
            }
        }

        private int addValues(int leftHandSide, int rightHandSide)
        {
            lblExpresion.Text = leftHandSide.ToString() + " + " + rightHandSide.ToString();
            return leftHandSide + rightHandSide;
        }

        private int subtractValues(int leftHandSide, int rightHandSide)
        {
            lblExpresion.Text = leftHandSide.ToString() + " - " + rightHandSide.ToString();
            return leftHandSide - rightHandSide;
        }

        private int multiplyValues(int leftHandSide, int rightHandSide)
        {
            lblExpresion.Text = leftHandSide.ToString() + " * " + rightHandSide.ToString();
            return leftHandSide * rightHandSide;
        }

        private int divideValues(int leftHandSide, int rightHandSide)
        {
            lblExpresion.Text = leftHandSide.ToString() + " / " + rightHandSide.ToString();
            return leftHandSide / rightHandSide;
        }

        private int remainderValues(int leftHandSide, int rightHandSide)
        {
            lblExpresion.Text = leftHandSide.ToString() + " % " + rightHandSide.ToString();
            return leftHandSide % rightHandSide;
        }

        private void showResult(int answer)
        {
            lblResultado.Text = answer.ToString();
        }
    }
}
