﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WhileStatement
{
    public partial class Principal : Form
    {
        private OpenFileDialog openFileDialog = null;

        public Principal()
        {
            InitializeComponent();
            openFileDialog = new OpenFileDialog();
            openFileDialog.FileOk += openFileDialogFileOk;
        }

        private void openFileClick(object sender, EventArgs e)
        {
            openFileDialog.ShowDialog();
        }

        private void openFileDialogFileOk(object sender, CancelEventArgs e)
        {
            string fullPathname = openFileDialog.FileName;
            FileInfo src = new FileInfo(fullPathname);
            txtNombreArchivo.Text = src.FullName;
            TextReader reader = src.OpenText();
            displayData(reader);
        }

        private void displayData(TextReader reader)
        {
            // TODO: add while loop here
            

        }

    }
}
